#!/bin/bash
create_username() {
IFS="@" read -ra parts <<< $email
IFS="." read -ra name_parts <<< ${parts[0]}
local first_name=${name_parts[0]}
local surname=${name_parts[1]}
username=${surname:0:1}${first_name^} # splice surname to get first letter, append first name to the end to get desired username
echo Username created
create_user $username # call create user function
}

create_user() {
sudo useradd -d /home/$username -m -s /bin/bash $username # add a user or each username
if [  $? -eq 0 ]; then
	echo "user added"
else
	echo "user creation error"
fi
}

passwd_generate() {
year_month="${birthdate//\//-}"  # Replace slashes with hyphens
default_password="${year_month%-*}"  # Remove the day part (DD) and keep YYYY-MM
default_password="${default_password//-/}"  # Remove hyphens to get YYYYMM
echo "$username:$default_password" | sudo chpasswd # implement default password
if [ $? -eq 0 ]; then
	echo "default password set"
else
	echo "default password was not set"
fi
sudo chage -d 0 $username # force user to change password on login
if [ $? -eq 0 ];then
	echo "user password restrictions set"
else
	echo "password restrictions error"
fi
}

shared_folder() {
if [ -d $shared_folder ]; then
	echo Shared folder already exists
else
	sudo mkdir $shared_folder
	echo Folder created
fi
}

marker=0
while [ marker=0 ]
do
	if [ $# -ne 1 ]; then
		echo "Please enter your local csv file location"
		read csv_file
	fi
	if [ $# -ne 0 ]; then
		csv_file=$1
	fi
	if [ -f "$csv_file" ]; then
		echo "$csv_file exists"
		break
	else
		echo "File $csv_file does not exist"
	fi
done

while IFS=";" read -r email birthdate secondary_groups shared_folder
do
	create_username $email
	passwd_generate $birthdate
	echo $secondary_groups
	shared_folder $shared_folder
	echo ""
done < <(tail -n +2 $csv_file)
