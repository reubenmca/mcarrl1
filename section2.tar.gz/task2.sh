#/bin/bash
marker=0
while [ marker=0 ]
do
if [ $# -ne 1 ]; then
	echo "Please enter the directory you want compressed:"
	read dir
fi
if [ $# -ne 0 ]; then
	dir=$1
fi
if [ -d "$dir" ]; then
echo "Directory exists"
break
else
echo "Directory $dir does not exist"
fi
done

tar -czvf $dir.tar.gz $dir #create .tar.gz file

#ask user for inputs
echo Please enter the ip address or URL of remote server
read address
echo Please enter the port number of remote server
read port
echo Please enter the target directory to save the tarball archive
read target

scp -P "$port" "$dir.tar.gz" "$address":"$target" # send archive file via scp

if [ $? -eq 0 ]; then
	echo "Upload successful"
else
	echo "Error: upload failed"
fi

#tidy up
rm "$dir.tar.gz"

